package com.mycompany.livrocad;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import DAOs.DAOLivro;
import Entidades.Livro;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Usuario
 */
@WebServlet(name = "ServletAnotation", urlPatterns = {"/ServletAnotation"})
public class ServletAnotation extends HttpServlet {

    List<Livro> lista = new ArrayList<>();
    DAOLivro controle = new DAOLivro();

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ServletAnotation</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet ServletAnotation at " + request.getContextPath() + "</h1>");

            lista = controle.list();
            out.println("<h1>" + lista + "</h1>");

            out.println("</body>");
            out.println("</html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String isbn = req.getParameter("isbn");
        String titulo = req.getParameter("titulo");
        String anoP = req.getParameter("anoP");
        String edicao = req.getParameter("edicao");
        String autor = req.getParameter("autor");
        String editora = req.getParameter("editora");
        String sinopse = req.getParameter("sinopse");

        Livro livro = new Livro();
        livro.setIsbn(controle.autoIdLivro());

        if (isbn != null) {
            livro.setIsbn(Integer.parseInt(isbn));
        }
        if (titulo != null) {
            livro.setTitulo(titulo);
        }
        if (autor != null){
        livro.setAutor(autor);
        }
        if (editora != null){
        livro.setEditora(editora);
        }
        if (edicao != null) {
            livro.setEdicao(Integer.parseInt(edicao));
        }
        if (anoP != null) {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            try {
                livro.setAnoPublic(sdf.parse(anoP));
            } catch (ParseException ex) {
                Logger.getLogger(ServletAnotation.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        livro.setSinopse(sinopse);
        
        controle.inserir(livro);

        processRequest(req, resp);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
