package DAOs;

import Entidades.Livro;
import java.util.ArrayList;
import java.util.List;
import static DAOs.DAOGenerico.em;
import java.text.SimpleDateFormat;

public class DAOLivro extends DAOGenerico<Livro> {

    public DAOLivro() {
        super(Livro.class);
    }

    public int autoIdLivro() {
        Integer a = (Integer) em.createQuery("SELECT MAX(e.isbn) FROM Livro e ").getSingleResult();
        if (a != null) {
            return a + 1;
        } else {
            return 1;
        }
    }

    public static List<Livro> listByIsbn(int isbn) {
        return em.createQuery("SELECT e FROM Livro e WHERE e.isbn = :isbn").setParameter("isbn", isbn).getResultList();
    }

    public static List<Livro> listByTitulo(String titulo) {
        return em.createQuery("SELECT e FROM Livro e WHERE e.titulo LIKE :titulo").setParameter("titulo", "%" + titulo + "%").getResultList();
    }

    public static List<Livro> listInOrderIsbn() {
        return em.createQuery("SELECT e FROM Livro e ORDER BY e.isbn").getResultList();
    }

    public static List<Livro> listInOrderTitulo() {
        return em.createQuery("SELECT e FROM Livro e ORDER BY e.titulo").getResultList();
    }

    public static List<String> listInOrderNomeStrings(String qualOrdem) {
        List<Livro> lf;
        if (qualOrdem.equals("isbn")) {
            lf = listInOrderIsbn();
        } else {
            lf = listInOrderTitulo();
        }

        List<String> ls = new ArrayList<>();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        for (int i = 0; i < lf.size(); i++) {
            ls.add(lf.get(i).getIsbn() + ";" + lf.get(i).getTitulo() + ";" + sdf.format(lf.get(i).getAnoPublic()) + ";" + lf.get(i).getEdicao() + ";" + lf.get(i).getAutor() + ";" + lf.get(i).getEditora() + ";" + lf.get(i).getSinopse() + ";");
        }
        return ls;
    }
}

